# Kompilator 2020
Instalacja bibliotek:
```
sudo apt-get update
sudo apt-get install python3
sudo apt-get install python3-pip
pip3 install sly
```
Uruchamianie:

`python3 main.py <plik_wejsciowy> <plik wyjsciowy>`